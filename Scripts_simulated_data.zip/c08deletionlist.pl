#!perl -w
use strict;


my @fasta; my @ftemp; my @fout; my @faa; my $temp;
my $numg; my $nums;
my $aa; my $codon;
my $file; my @result; my @result2; my $count;

my @sp; my @leng;
$sp[0] = "0_1_2";
$sp[1] = "01_2_6";
$sp[2] = "012_345_6";
$sp[3] = "3_4_5";
$sp[4] = "34_5_0";
$sp[5] = "6_78_0";
$sp[6] = "7_8_6";
@leng = (0.012813, 0.057737, 0.148787, 0.175436, 0.435876, 0.183694, 0.266659);
my %ks; my $k;
$ks{"CLUSTALW"} = 0; $ks{"TCOFFEE"} = 1; $ks{"PROBCONS"} = 2; $ks{"TRUE"} = 3;
my @methods;
$methods[0] = "CLUSTALW";
$methods[1] = "TCOFFEE";
$methods[2] = "PROBCONS";
$methods[3] = "TRUE";
my @valids; my @dels;
my @data; my @b; my $pos; my $t1; my $t2;

foreach $numg (1..8595) {
 @valids = ();
 @dels = ();
 foreach $file (0..6) {
  open (VALIDS, "Data/$numg/Gene_$numg\_sp_$sp[$file]\_Valid_Sites.txt");
  @data = <VALIDS>;
  foreach (@data) {
   chomp;
   @b = split "\t", $_;
   $pos = (($b[1]-1)*10000)+$b[3];
   $valids[$ks{$b[2]}][$pos] += $leng[$file];
   
  }
  
  
  open (DELS, "Data/$numg/Gene_$numg\_sp_$sp[$file]\_Deletions.txt");
  @data = <DELS>;
  unless ($#data >= 0) {next;}
  foreach (@data) {
   chomp;
   @b = split "\t", $_;
   $pos = (($b[1]-1)*10000)+$b[3];
   $dels[$ks{$b[2]}][$pos] += 1;
   
  }
  
 
 }
 
 
 foreach $k (0..3) {
  @result = ();
  @result2 = ();
  foreach (1..50000) {
   $t1 = (int($_/10000))+1; $t2 = $_%10000;
   if (defined ($valids[$k][$_])) {push @result, "$numg\t$t1\t$t2\t$methods[$k]\t$valids[$k][$_]\n";}
   if (defined ($dels[$k][$_])) {push @result2, "$numg\t$t1\t$t2\t$methods[$k]\t$dels[$k][$_]\n";}
  
  }
 
 
  open(FILEHANDLE, ">Data/$numg/Gene_$numg\_Valid_Sites_$methods[$k].txt");
  print FILEHANDLE @result;
  open(FILEHANDLE, ">Data/$numg/Gene_$numg\_Deletions_$methods[$k].txt");
  print FILEHANDLE @result2;

 }
 print "$numg\n";
}
