#!perl -w
use warnings;
use strict;


my @result;
my $numg = $ARGV[0]; #Code of gene
my $k = $ARGV[1]; #Method of alignment; PROBCONS in this case

open (TREE, "tree.nwk");
my @tree = <TREE>;
open(FILEHANDLE, ">Tree_$numg\_$k.nwk");
print FILEHANDLE @tree;

open (DATA,">Batch_$numg\_$k.txt");
print DATA "#!/bin/sh\n";
print DATA "/project/moleval/Yichen/hyphy-master/HYPHYMP FUBAR.bf <<END1\n";
print DATA "1\n";
print DATA "1\n";
print DATA "/project/moleval/Yichen/Mammal_9_species/Realign/$k\_nuc/$numg\_$k.phy\n";
print DATA "/project/moleval/Yichen/Mammal_9_species/Realign/Tree_$numg\_$k.nwk\n";
print DATA "1\n";
print DATA "20\n";
print DATA "5\n";
print DATA "2000000\n";
print DATA "1000000\n";
print DATA "100\n";
print DATA "0.5\n";
print DATA "END1\n";
close DATA;
my $command="sh Batch_$numg\_$k.txt";
system($command);


unlink "Tree_$numg\_$k.nwk.codon_fit";
unlink "Tree_$numg\_$k.nwk.grid_info";
unlink "Tree_$numg\_$k.nwk.gtr_fit";
unlink "Tree_$numg\_$k.nwk.samples";
unlink "Tree_$numg\_$k.nwk.samples.0";
unlink "Tree_$numg\_$k.nwk.samples.1";
unlink "Tree_$numg\_$k.nwk.samples.2";
unlink "Tree_$numg\_$k.nwk.samples.3";
unlink "Tree_$numg\_$k.nwk.samples.4";
unlink "Tree_$numg\_$k.nwk";
unlink "Batch_$numg\_$k.txt";

open (OUT, "Tree_$numg\_$k.nwk.fubar.csv");
my @out = <OUT>;
foreach (@out) {
 unless (/^([\w\.]+),([\w\.]+),([\w\.]+),/) {next;}
 push @result, "$1\t$2\t$3\n";

}
open(FILEHANDLE, ">$k\_FUBAR/$numg\_$k\_fubar.txt");
print FILEHANDLE @result;

unlink "Tree_$numg\_$k.nwk.fubar.csv";
