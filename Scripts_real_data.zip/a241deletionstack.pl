#!perl -w
use strict;


my @fasta; my @ftemp; my @fout; my @faa; my $temp;
my $numg; my $nums;
my $aa; my $codon;
my $file; my @result; my @result2; my $count;

my @sp; my @leng;
$sp[0] = "0_1_2";
$sp[1] = "01_2_6";
$sp[2] = "012_345_6";
$sp[3] = "3_4_5";
$sp[4] = "34_5_0";
$sp[5] = "6_78_0";
$sp[6] = "7_8_6";
@leng = (0.012813, 0.057737, 0.148787, 0.175436, 0.435876, 0.183694, 0.266659);
my %ks; my $k;
$ks{"CLUSTALW"} = 0; $ks{"TCOFFEE"} = 1; $ks{"PROBCONS"} = 2;
my @methods;
$methods[0] = "CLUSTALW";
$methods[1] = "TCOFFEE";
$methods[2] = "PROBCONS"; #From earlier stages where multiple alignment methods were tried; we only kept PROBCONS
my @valids; my @dels;
my @data; my @b; my $pos; my $t1; my $t2;

open (GLIST, "Genelist_9sp_longtree_removed.txt");
my @genelist = <GLIST>;



foreach $numg (@genelist) {
 chomp $numg;
 @valids = ();
 @dels = ();
 foreach $file (0..6) {
  open (VALIDS, "Deletion2/Total/$numg\_sp_$sp[$file]\_Valid_Sites.txt") or next;
  @data = <VALIDS>;
  foreach (@data) {
   chomp;
   @b = split "\t", $_;
   $pos = $b[2];
   $valids[$ks{$b[1]}][$pos] += $leng[$file];
   
  }
  
  
  open (DELS, "Deletion2/Total/$numg\_sp_$sp[$file]\_Deletions.txt");
  @data = <DELS>;
  unless ($#data >= 0) {next;}
  foreach (@data) {
   chomp;
   @b = split "\t", $_;
   $pos = $b[2];
   $dels[$ks{$b[1]}][$pos] += 1;
   
  }
  
 
 }
 
 
 foreach $k (0..2) {
  @result = ();
  @result2 = ();
  foreach (1..5000) {
   if (defined ($valids[$k][$_])) {push @result, "$numg\t$_\t$methods[$k]\t$valids[$k][$_]\n";}
   if (defined ($dels[$k][$_])) {push @result2, "$numg\t$_\t$methods[$k]\t$dels[$k][$_]\n";}
  
  }
 
 
  open(FILEHANDLE, ">Deletion2/$methods[$k]/$numg\_Valid_Sites_$methods[$k].txt");
  print FILEHANDLE @result;
  open(FILEHANDLE, ">Deletion2/$methods[$k]/$numg\_Deletions_$methods[$k].txt");
  print FILEHANDLE @result2;

 }
 print "$numg\n";
}
