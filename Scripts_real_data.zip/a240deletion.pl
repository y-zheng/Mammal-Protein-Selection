#!perl -w
use strict;

my @result; my @fasta; my @nucs;
my @data; my @ftemp; my @fout;
my $aa; my $codon; my $temp;
my $seq; my $head;
my $nums; my $numg; my $k;
my @methods;
my $counta; my @heads; my @seqs; my @seqsnuc; my @seqsnew; my $place;
my $leng;
$methods[0] = "CLUSTALW";
$methods[1] = "TCOFFEE";
$methods[2] = "PROBCONS";

open (GLIST, "Genelist_9sp_longtree_removed.txt");
my @genelist = <GLIST>;



#species: 0-human 1-chimp 2-macaque 3-mouse 4-rat 5-gpig 6-cow 7-horse 8-dog

#Here we input what trio of species or groups we use for the deletion detection. It need to be run one time for each branch pair.
#$trio[2] is outgroup of the three
my @trio = @ARGV;

my @seqsp0; my @seqsp1; my @seqsp2; my @newsp; my @b;
my @seqst; my $length; my @valid; my @del0; my @del1;
my @result2;
my $dseq; my $dsize; my $dplace; my $special;

foreach (0..8) {$newsp[$_] = -1;}
@b = split "", $trio[0];
foreach (@b) {$newsp[$_] = 0;}
@b = split "", $trio[1];
foreach (@b) {$newsp[$_] = 1;}
@b = split "", $trio[2];
foreach (@b) {$newsp[$_] = 2;}



 foreach $numg (@genelist) {
  @result = (); @result2 = ();
  chomp $numg;
   
   foreach $k (@methods) {
    open (FASTA, "$k/$numg\_$k.fas") or next;
    @fasta = <FASTA>; @heads = (); @seqs = (); @seqst = (); $counta = -1;
    @seqsp0 = (); @seqsp1 = (); @seqsp2 = (); 
    foreach (@fasta) {
     chomp;
     if (/^>/) {$counta += 1; $heads[$counta] .= $_;}
     else {$seqs[$counta] .= $_;}
    }
    
    foreach (0..$counta) {
     if ($newsp[$_] == 0) {push @seqsp0, $seqs[$_];}
     if ($newsp[$_] == 1) {push @seqsp1, $seqs[$_];}
     if ($newsp[$_] == 2) {push @seqsp2, $seqs[$_];}
    }
    
    $seqst[0] = &combine(@seqsp0);
    $seqst[1] = &combine(@seqsp1);
    $seqst[2] = &combine(@seqsp2);
   
    $length = (length $seqst[0]);
    @valid = (); @del0 = (); @del1 = ();
    foreach (0..($length-1)) {$valid[$_] = 1;}
   
   # All terminal gaps are not valid sites;
    foreach (0..($length-1)) {
     if ((substr $seqst[0], $_, 1) eq "-") {$valid[$_] = 0;}
     else {last;}
    }
    foreach (0..($length-1)) {
     if ((substr $seqst[1], $_, 1) eq "-") {$valid[$_] = 0;}
     else {last;}
    }
    foreach (0..($length-1)) {
     if ((substr $seqst[0], ($length-$_-1), 1) eq "-") {$valid[$length-$_-1] = -1;}
     else {last;}
    }
    foreach (0..($length-1)) {
     if ((substr $seqst[1], ($length-$_-1), 1) eq "-") {$valid[$length-$_-1] = -1;}
     else {last;}
    }
 
   # All gaps in outgroup or BOTH non-outgroups are not valid sites; all sites with "X" are not valid sites; all inconsistent sites are not valid.
    foreach (0..($length-1)) {
     if ((substr $seqst[2], $_, 1) eq "-") {$valid[$_] = 0;}
     if (((substr $seqst[0], $_, 1) eq "-") &&((substr $seqst[1], $_, 1) eq "-")) {$valid[$_] = 0;}
     if ((substr $seqst[0], $_, 1) eq "X") {$valid[$_] = -2;}
     if ((substr $seqst[1], $_, 1) eq "X") {$valid[$_] = -2;}
     if ((substr $seqst[2], $_, 1) eq "X") {$valid[$_] = -2;}
    }
 
    $dseq = -1; $dsize = 0; $dplace = -1; $special = 0;
 
    foreach (0..($length-1)) {
     if ($dsize == 0) { # Not in deletion
      unless ($valid[$_] == 1) {next;}
      if (((substr $seqst[0], $_, 1) eq "-") &&((substr $seqst[1], $_, 1) ne "-")) {$dseq = 0; $dsize = 1; $dplace = $_; $special = 0;}
      if (((substr $seqst[0], $_, 1) ne "-") &&((substr $seqst[1], $_, 1) eq "-")) {$dseq = 1; $dsize = 1; $dplace = $_; $special = 0;}
     }
     else { # In deletion
      if ($valid[$_] == 1) { # A valid site
       if (((substr $seqst[0], $_, 1) eq "-") &&((substr $seqst[1], $_, 1) ne "-") && ($dseq == 0)) {$dsize += 1;} # Continue deletion
       if (((substr $seqst[0], $_, 1) ne "-") &&((substr $seqst[1], $_, 1) eq "-") && ($dseq == 1)) {$dsize += 1;}
       
       if (((substr $seqst[0], $_, 1) ne "-") &&((substr $seqst[1], $_, 1) ne "-")) { # Deletion ends normally
        &enddeletion;
       }
       if (((substr $seqst[0], $_, 1) eq "-") &&((substr $seqst[1], $_, 1) ne "-") && ($dseq == 1)) { # A deletion in the other sequence starts
        &enddeletion;
        $dsize = 1; $dplace = $_; $dseq = 0; $special = 0;
       }
       if (((substr $seqst[0], $_, 1) ne "-") &&((substr $seqst[1], $_, 1) eq "-") && ($dseq == 0)) { # A deletion in the other sequence starts
        &enddeletion;
        $dsize = 1; $dplace = $_; $dseq = 1; $special = 0;
       }
      }
   
      elsif ($valid[$_] == 0) {# A non-valid site because of gaps
       if (((substr $seqst[0], $_, 1) eq "-") &&((substr $seqst[1], $_, 1) eq "-") && ((substr $seqst[2], $_, 1) eq "-")) { # All-gap site; continue
        $dsize += 1; $special += 1;
       }
       elsif (((substr $seqst[0], $_, 1) ne "-") &&((substr $seqst[1], $_, 1) eq "-") && ((substr $seqst[2], $_, 1) eq "-")) {
        if ($dseq == 1) {$dsize += 1; $special += 1;}
        else {&enddeletion;}
       }
       elsif (((substr $seqst[0], $_, 1) eq "-") &&((substr $seqst[1], $_, 1) ne "-") && ((substr $seqst[2], $_, 1) eq "-")) {
        if ($dseq == 0) {$dsize += 1; $special += 1;}
        else {&enddeletion;}
       }
       elsif (((substr $seqst[0], $_, 1) eq "-") &&((substr $seqst[1], $_, 1) eq "-") && ((substr $seqst[2], $_, 1) ne "-")) { # "All-gap" site; continue
        $dsize += 1; $special += 1;
       }
       else {&enddeletion;}
      }
  
      elsif ($valid[$_] == -1) { # Terminal gaps, finish this deletion and end file
       &enddeletion;
       last;
      }
  
      elsif ($valid[$_] == -2) { # A non-valid site because of "X"
       if (((substr $seqst[0], $_, 1) ne "-") &&((substr $seqst[1], $_, 1) ne "-") && ((substr $seqst[2], $_, 1) ne "-")) {
        &enddeletion;
       }
       elsif (((substr $seqst[0], $_, 1) ne "-") &&((substr $seqst[1], $_, 1) eq "-") && ((substr $seqst[2], $_, 1) ne "-")) {
        if ($dseq == 1) {$dsize += 1;}
        else {&enddeletion;}
       }
       elsif (((substr $seqst[0], $_, 1) eq "-") &&((substr $seqst[1], $_, 1) ne "-") && ((substr $seqst[2], $_, 1) ne "-")) {
        if ($dseq == 0) {$dsize += 1;}
        else {&enddeletion;}
       }
       elsif (((substr $seqst[0], $_, 1) eq "-") &&((substr $seqst[1], $_, 1) eq "-") && ((substr $seqst[2], $_, 1) ne "-")) {
        $dsize += 1; $special += 1;
       }
       elsif (((substr $seqst[0], $_, 1) ne "-") &&((substr $seqst[1], $_, 1) ne "-") && ((substr $seqst[2], $_, 1) eq "-")) {
        &enddeletion;
       }
       elsif (((substr $seqst[0], $_, 1) ne "-") &&((substr $seqst[1], $_, 1) eq "-") && ((substr $seqst[2], $_, 1) eq "-")) {
        if ($dseq == 1) {$dsize += 1; $special += 1;}
        else {&enddeletion;}
       }
       elsif (((substr $seqst[0], $_, 1) eq "-") &&((substr $seqst[1], $_, 1) ne "-") && ((substr $seqst[2], $_, 1) eq "-")) {
        if ($dseq == 0) {$dsize += 1; $special += 1;}
        else {&enddeletion;}
       }
       else {&enddeletion;}
      }
   
     }
 
 
    }
 
 
 
 
    foreach (0..($length-1)) {
     if ($valid[$_] == 1) {push @result, ("$numg\t$k\t".($_+1)."\n");}
    }
    foreach (@del0) {
     push @result2, ("$numg\t$k\t".($_+1)."\n");
    }
    foreach (@del1) {
     push @result2, ("$numg\t$k\t".($_+1)."\n");
    }
 
    
    
    
   }
   
  print "$numg\n";
   open(FILEHANDLE, ">Raw Deletions Alt Tree/$numg\_sp_$trio[0]\_$trio[1]\_$trio[2]\_Valid_Sites.txt");
  print FILEHANDLE @result;
   open(FILEHANDLE, ">Raw Deletions Alt Tree/$numg\_sp_$trio[0]\_$trio[1]\_$trio[2]\_Deletions.txt");
  print FILEHANDLE @result2;
  }




sub enddeletion {
 my $temp;
     if (($dsize - $special) <= 8 && $dseq == 0) { # Deletions <= 8aa are accepted
      foreach $temp (1..$dsize) {if ($valid[$dplace+$temp-1] == 1) {push @del0, ($dplace+$temp-1);}}
     }
     elsif (($dsize - $special) <= 8 && $dseq == 1) { # Deletions <= 8aa are accepted
      foreach $temp (1..$dsize) {if ($valid[$dplace+$temp-1] == 1) {push @del1, ($dplace+$temp-1);}}
     }
     else { # Deletions > 8aa are not valid sites
      foreach $temp (1..$dsize) {$valid[$dplace+$temp-1] = 0;}
     }
     $dsize = 0; $special = 0;

     
}

sub combine {
 my $seql; my $newseq; my $column; my $temp;
 if ($#_ == 0) {return ($_[0]);}
 else {
  $seql = length $_[0];
  $newseq = "";
  foreach $temp (0..($seql-1)) {
   $column = "";
   foreach (@_) {$column .= substr $_, $temp, 1;}
   if ($column =~ /^[A-Za-z]+$/) {$newseq .= substr $column, 0, 1;}
   elsif ($column =~ /^-+$/) {$newseq .= "-";}
   else {$newseq .= "=";}
  }
  return $newseq;
 }
 
 
}
